#header files
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import *
import tkinter
import json
from PIL import ImageTk,Image
from tkinter.filedialog import asksaveasfile


#main start

root=Tk()
root.title("Chitkara University Student Database")
root.geometry('400x400')
root.config(bg='black')

#header frame(2-images,label)

frame1=tkinter.Frame(root)
frame1.config(bg="black")
frame1.grid()
canvas=Canvas(frame1,highlightthickness=0,width=250,height=130)
canvas.grid(row=1,column=0)
img=ImageTk.PhotoImage(Image.open("image2.jpg"))
canvas.create_image(0,0,anchor=NW,image=img)

canvas1=Canvas(frame1,highlightthickness=0,bg="black",width=1000,height=130)
canvas1.grid(row=1,column=5)
label=tkinter.Label(canvas1,text="Chitkara University",font="Timesnewroman 25 bold",fg='white',bg='black')
label.pack(anchor=CENTER,padx=355,pady=12)

canvas2=Canvas(frame1,highlightthickness=0,width=252,height=130)
canvas2.grid(row=1,column=12)
img1=ImageTk.PhotoImage(Image.open("image1.png"))
canvas2.create_image(0,0,anchor=NW,image=img1)

#canvas with label of "student database"
canvas3=Canvas(root,highlightthickness=0,bg="black",height=30)
canvas3.grid()
label1=tkinter.Label(canvas3,text="STUDENT DATABASE",font="Timesnewroman 20 bold",fg='white',bg='black')
label1.pack(anchor=CENTER)

# notebook formation
mainFrame=Frame(root,width=200,height=200)
mainFrame.grid()

tabControl=Notebook(mainFrame)
tab1=Frame(tabControl)
tab2=Frame(tabControl)
tab3=Frame(tabControl)
tab4=Frame(tabControl)
tab5=Frame(tabControl)

tabControl.add(tab1,text="New Student")
tabControl.add(tab2,text='Display')
tabControl.add(tab3,text="Course Creation")
tabControl.add(tab4,text="Display Courses")
tabControl.add(tab5,text='Course Allocation')

tabControl.pack(expand=1,fill="both")

#New Student entry status

namevalue=StringVar()
rollvalue=StringVar()
addressvalue=StringVar()
phonevalue=StringVar()
gender=StringVar()

Label(tab1,text="Enter Your Name").grid(column=0,row=0,padx=25,pady=5)
first=Entry(tab1,width=20,textvariable=namevalue)
first.grid(padx=50,column=15,row=0)

Label(tab1,text="Enter Your RollNo.").grid(column=0,row=1,padx=25,pady=5)
rollno=Entry(tab1,width=20,textvariable=rollvalue)
rollno.grid(padx=50,column=15,row=1)

Label(tab1,text="Choose Your Gender").grid(column=0,row=2,padx=25,pady=5)
_m='Male'
_f='Female'
radio1=Radiobutton(tab1,text="Male",variable=gender,value=_m)
radio1.grid(padx=40,column=13,row=2)
radio2=Radiobutton(tab1,text="Female",variable=gender,value=_f)
radio2.grid(padx=20,column=15,row=2)

Label(tab1,text="Address for Correspondence").grid(column=0,row=3,padx=25,pady=5)
address=Entry(tab1,width=20,textvariable=addressvalue)
address.grid(padx=50,column=15,row=3)

Label(tab1,text="Phone Number").grid(column=0,row=4,padx=25,pady=5)
phone=Entry(tab1,width=20,textvariable=phonevalue)
phone.grid(padx=50,column=15,row=4)

Label(tab1,text="Your Batch").grid(column=0,row=5,padx=25,pady=5)
n=StringVar()
batch=Combobox(tab1,width=20,textvariable=n)
batch['values']=('Batch2017','Batch2018','Batch2019','Batch2020')
batch.grid(column=15,row=5,padx=50)
batch.current()

Label(tab1,text="Hostel[Y/N]").grid(column=0,row=6,padx=25,pady=5)
var1=BooleanVar()
box=Checkbutton(tab1,text="Click if you need hostel facility",variable=var1)
box.grid(column=15,padx=50,row=6)



#Tree View Widget

columns=('#1','#2','#3','#4','#5','#6','#7')
tree=Treeview(tab2,column=columns)
tree.heading('#0', text='Roll No.')
tree.heading('#1', text='Name')
tree.heading('#2', text='Gender')
tree.heading('#3', text='Address')
tree.heading('#4', text='PhoneNo')
tree.heading('#5', text='Batch')
tree.heading('#6', text='Hostel')
#columns
tree.column('#0',width=60)
tree.column('#1',width=70)
tree.column('#2',width=50)
tree.column('#3',width=150)
tree.column('#4',width=100)
tree.column('#5',width=50)
tree.column('#6',width=70)
tree.column('#7',width=0)

tree.grid()
treeview=tree

#defining entry for save button
def insert_data():
    i=0
    treeview.insert('',index='end',values=(rollvalue.get(),namevalue.get(),gender.get(),addressvalue.get(),phonevalue.get(),n.get().var1.get()))
    
    i=i+1
    
#Function for json file
def writeToJSONFile(path,filename,data):
    json.dump(data,path)

path='./'

def check():
    a=first.get()
    b=rollno.get()
    c1=gender.get()
    d=address.get()
    e=phone.get()
    f=n.get()
    g=var1.get()
    print(a)
    print(b)
    print(c1)
    print(d)
    print(e)
    print(f)
    print(g)
    
    data={}
    data['Name']=a
    data['Rollno']=b
    data['Gender'] = c1
    data['Address'] = d
    data['PhoneNo'] = e
    data['Batch'] = f
    data['Hostel'] = g
    files = [('JSON File', '*.json')]
    fileName = 'Students'
    filepos = asksaveasfile(filetypes=files, defaultextension=json, initialfile='Students')
    writeToJSONFile(filepos, fileName, data)

def multi_func():
    saveDetails()
    check()
    insert_data()
    
def saveDetails():
    messagebox.showinfo("Save","Your record has been saved")


def clearDetails():
    first.delete(0,'end')
    rollno.delete(0,'end')
    gender.set(0)
    var1.set(0)
    address.delete(0,'end')
    phone.delete(0,'end')


Button(tab1,text="Save",width=12,command=multi_func).grid(column=5,row=7,padx=0,pady=10)
Button(tab1,text="Clear",width=12,command=clearDetails).grid(column=7,row=7,padx=0,pady=10)

#COURSE CREATION

courseid=StringVar()
Label(tab3,text="Course ID").grid(column=0,row=0,padx=25,pady=5)
id=Entry(tab3)
id.grid(padx=50,column=15,row=0)

course_name=StringVar()
Label(tab3,text="Course Name").grid(column=0,row=1,padx=25,pady=5)
c_name=Entry(tab3)
c_name.grid(padx=50,column=15,row=1)

#Tree View for Tab4
columns=('#1','#2')
tree1=Treeview(tab4,columns=columns)
tree1.heading('#0', text='S No.')
tree1.heading('#1', text='Course ID')
tree1.heading('#2', text='Course Name')

tree1.column('#0')
tree1.column('#1')
tree1.column('#2')

tree1.grid(row=2, columnspan=2)
treeview1 = tree1

def writeToJSONFile1(path1, fileName1, data1):
    json.dump(data1, path1)


path1 = './'


def check1():
    m = id.get()
    n = c_name.get()
    print(m)
    print(n)
    data1 = {}
    data1['Course Id'] = m
    data1['Course Name'] = n
    files = [('JSON File', '*.json')]
    fileName1 = 'Course'
    filepos = asksaveasfile(filetypes=files, defaultextension=json, initialfile='Course')
    writeToJSONFile1(filepos, fileName1, data1)

def insert_data1():
    i = 0
    treeview1.insert('', index='end',
                       values=(courseid.get(),course_name.get()))

    i = i + 1


def delete1():
    id.delete(0, 'end')
    c_name.delete(0, 'end')


def multi_func1():
    insert_data1()
    check1()
    
Button(tab3,text="Save",width=15,command=multi_func1).grid(column=5,row=7,padx=0,pady=10)
Button(tab3,text="Clear",width=15,command=delete1).grid(column=7,row=7,padx=0,pady=10)


#tab5
Label(tab5, text='Student Roll No :').grid(column=0,row=0,padx=25,pady=5)
box_8 = StringVar()
e8 = Entry(tab5, width=75, textvariable=box_8).grid(padx=50,column=15,row=0)


Label(tab5, text='Course Name :').grid(column=0,row=1,padx=25,pady=5)
box_9 = StringVar()
e9 =Combobox(tab5, width=75, textvariable=box_9, values=['Programming in C', 'Problem Solving With Python',
                                 'Object Oriented Programming in Linux', 'Introduction to Linux',
                                 'Database Management System', 'Computer Networks', 'Advanced Web Technologies'])
e9.grid(padx=50,column=15,row=1)


def writeToJSONFile2(path2, fileName2, data2):
    json.dump(data2, path2)


path2 = './'


def check2():
    x = e8.get()
    y = box_9.get()
    print(x)
    print(y)
    data2 = {}
    data2['RollNo'] = x
    data2['Course'] = y
    files = [('JSON File', '*.json')]
    fileName2 = 'Allocation'
    filepos = asksaveasfile(filetypes=files, defaultextension=json, initialfile='Allocation')
    writeToJSONFile(filepos, fileName2, data2)


# Save and Clear buttons below
Button(tab5, text='Allocate', width=15, command=check2).grid(column=5,row=7,padx=0,pady=10)


canvas4=Canvas(root,highlightthickness=0,bg="black",height=80)
canvas4.grid(pady=35)
label1=tkinter.Label(canvas4,text="Department of Computer Science & Engineering",font="Timesnewroman 18 bold",fg='white',bg='black')
label1.pack(anchor=CENTER)

mainloop()

