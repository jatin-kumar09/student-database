import tkinter
from tkinter import *
from tkinter import ttk
from tkinter.ttk import Notebook,Treeview
from PIL import ImageTk,Image
from tkinter import messagebox
import json

root=Tk()
root.geometry("450x350")     #geometry(widthxheight)
root.title('Chitkara University Student Database')   #title
root.configure(background='black')        #background color


#making a frame
frame1=Frame(root)
frame1.config(bg='black')
frame1.grid()

canvas=Canvas(frame1,highlightthickness=0,width=250,height=130)
canvas.grid(row=1,column=0)
img=ImageTk.PhotoImage(Image.open("image2.jpg"))
canvas.create_image(0,0,anchor=NW,image=img)

canvas1=Canvas(frame1,highlightthickness=0,width=1000,height=130,bg='black')
canvas1.grid(row=1,column=5)
label=tkinter.Label(canvas1,text="Chitkara University",font="TImesnewroman 25 bold",fg='white',bg='black')
label.pack(anchor=CENTER,padx=355,pady=12)

canvas2=Canvas(frame1,highlightthickness=0,width=252,height=130)
canvas2.grid(row=1,column=12)
img1=ImageTk.PhotoImage(Image.open("image1.png"))
canvas2.create_image(0,0,anchor=NW,image=img1)

canvas3=Canvas(root,highlightthickness=0,bg='black',height=30)
canvas3.grid()
label1=tkinter.Label(canvas3,text="STUDENT DATABASE",font="Timesnewroman 20 bold",fg='white',bg='black')

#----------------------------NOTEBOOK WIDGET----------------------------------------

frame=Frame(root,width=300,height=200)
frame.grid()
tc = Notebook(frame)
tab1 = Frame(tc)
tab2 = Frame(tc)
tab3 = Frame(tc)
tab4 = Frame(tc)
tab5 = Frame(tc)
tab6 = Frame(tc)
tc.add(tab1, text ='New Student')
tc.add(tab2, text ='Display')
tc.add(tab3, text ='Course Creation')
tc.add(tab4, text ='Display Courses')
tc.add(tab5, text ='Course Allocation')
tc.pack(expand = 1, fill ="both")
#-----------------------------------------------------------------------------------
#------------------------------- window 1  New Student  ----------------------------
for i in range(6):
    tab1.columnconfigure(i,weight=1)#this for loop is to make columns
#----------------------------------------------------------------------row 0
Label(tab1,text ="Enter Your Name",font = ("Times New Roman", 12)).grid(column =0,row = 0,columnspan=2,sticky=E, padx = 10, pady = 10)
name=Entry(tab1,width=50,borderwidth=2)
name.grid(row=0,column=4,columnspan=2, padx = 10, pady = 10)
#----------------------------------------------------------------------row 1
Label(tab1,text ="Enter Your Roll No",font = ("Times New Roman", 12)).grid(column =0,row = 1,columnspan=2,sticky=E, padx = 10, pady = 10)
rollno=Entry(tab1,width=50,borderwidth=2)
rollno.grid(row=1,column=4,columnspan=2, padx = 10, pady = 10)
#----------------------------------------------------------------------row 2
Label(tab1,text ="Choose Your Gender",font = ("Times New Roman", 12)).grid(column =0,row = 2,columnspan=2,sticky=E, padx = 10, pady = 10)

#tristatevalue=0 means unchecked radio button
gender=StringVar()
Radiobutton(tab1,text="Male",value="Male",variable=gender,tristatevalue=0,font = ("Times New Roman", 12)).grid(column =4,row = 2,columnspan=1, padx = 10, pady = 10)
Radiobutton(tab1,text="Female",value="Female",variable=gender,tristatevalue=0,font = ("Times New Roman", 12)).grid(column =5,row = 2,columnspan=1, padx = 10, pady = 10)
#----------------------------------------------------------------------row 3
Label(tab1,text ="Address of Correspondance",font = ("Times New Roman", 12)).grid(column =0,row = 3,columnspan=2,sticky=E, padx = 10, pady = 10)
address=Entry(tab1,width=50,borderwidth=2)
address.grid(row=3,column=4,columnspan=2, padx = 10, pady = 10)
#----------------------------------------------------------------------row 4
Label(tab1,text ="Phone no",font = ("Times New Roman", 12)).grid(column =0,row = 4,columnspan=2,sticky=E, padx = 10, pady = 10)
phoneno=Entry(tab1,width=50,borderwidth=2)
phoneno.grid(row=4,column=4,columnspan=2, padx = 10, pady = 10)
#----------------------------------------------------------------------row 5
# Label 
Label(tab1, text = "Your Batch",font = ("Times New Roman", 12)).grid(column = 0,row = 5,columnspan=2, padx = 10, pady = 10,sticky=E) 
  
n=StringVar() 
batch = ttk.Combobox(tab1,state='readonly', width = 18,textvariable=n) 
# Adding combobox drop down list 
batch['values'] = ('2020','2019','2018','2017') 
 
batch.grid(column = 5, row = 5) 
# Shows Computer Science as a default value 
batch.current(0)
#----------------------------------------------------------------------row 6
Label(tab1,text ="Do you Want Hostel",font = ("Times New Roman", 12)).grid(column =0,row = 6,columnspan=2,sticky=E, padx = 10, pady = 10)
hostel=StringVar()
checkbox1= Checkbutton(tab1, text = "Yes",variable = hostel, 
                      onvalue = 'yes', 
                      offvalue = 'no', 
                      height = 2, 
                      width = 10)
checkbox1.grid(column =5,row = 6,columnspan=2,sticky=W, padx = 0, pady = 10)
checkbox1.deselect()

def clear1():
        name.delete(0,END)
        rollno.delete(0,END)
        address.delete(0,END)
        phoneno.delete(0,END)
def msg_submit():
    # showinfo ,showwarning,showerror,askquestion,askokcancel,askyesno
    messagebox.showinfo("Save", "Record added")
    clear1()
def msg_clear():
        messagebox.showinfo("Clear", "Cleared")
        clear1()
def std_det_add():
        d1=name.get()
        d2=rollno.get()
        d3=gender.get() 
        d4=address.get()
        d5=phoneno.get()
        d6=n.get()
        d7=hostel.get()
        d8=False
        if d7=='yes':
                d8=True
        msg_submit()
        r={ "Rollno": d2, "Name": d1,
         "Gender": d3,"address": d4,
         "Phone no": d5, "Batch": " Batch "+d6,
         "Hostel": d8
        }
        with open('Student.json') as f:
                data=json.load(f)
        data["Students"].append(r)
        data_serialise=json.dumps(data, indent=2)

        with open('Student.json','w') as f:
                json.dump(data,f,indent=1)

Button(tab1,text="Submit", width = 18,command=std_det_add).grid(column =3,row = 7,columnspan=1,sticky=W, padx = 10, pady = 10)
Button(tab1,text="Clear", width = 18,command=msg_clear).grid(column =4,row = 7,columnspan=1,sticky=W, padx = 10, pady = 10)





#-----------------------------------------------------------------------------------
#------------------------------Window 2 Diplay -------------------------------------

win2_tree=Treeview(tab2)
# define Our Columns
win2_tree['columns']=('RollNo','Name','Gender','Address','Phoneno','Batch','Hostel')
# Formate Our Columns
win2_tree.column('#0',width=0,minwidth=0)
win2_tree.column('RollNo',width=80,minwidth=80)
win2_tree.column('Name',width=120,minwidth=120)
win2_tree.column('Gender',width=80,minwidth=80)
win2_tree.column('Address',width=120,minwidth=120)
win2_tree.column('Phoneno',width=120,minwidth=120)
win2_tree.column('Batch',width=120,minwidth=120)
win2_tree.column('Hostel',width=80,minwidth=80)
# Create Headings
win2_tree.heading('#0',text="",anchor=W)
win2_tree.heading('RollNo',text="RollNo",anchor=W)
win2_tree.heading('Name',text="Name",anchor=W)
win2_tree.heading('Gender',text="Gender",anchor=W)
win2_tree.heading('Address',text="Address",anchor=W)
win2_tree.heading('Phoneno',text="Phoneno",anchor=W)
win2_tree.heading('Batch',text="Batch",anchor=W)
win2_tree.heading('Hostel',text="Hostel",anchor=W)
#------------ SHOW DETAILS-----------------------------------------------
def show():
        win2_tree.delete(*win2_tree.get_children())
        # insert data
        with open('Student.json') as f:
                data=json.load(f)
        temp=0
        for i in data['Students']:
                win2_tree.insert(parent='',index='end',iid=temp,text='',values=(i["Rollno"],i["Name"],i["Gender"],i["address"],i["Phone no"],i["Batch"],i['Hostel']))
                temp+=1
        # place
        win2_tree.place(x=0,y=0,width=800)

Button(tab2,text="Display",bg='black',fg='white',command=show).place(x=350,y=300)

#-----------------------------TAB-3--------------------------------------



for i in range(6):
    tab3.columnconfigure(i,weight=1) #columns formation

Label(tab3,text ="Course ID",font = ("Times New Roman", 12)).grid(column =1,row = 0,columnspan=2,sticky=E, padx = 10, pady = 45)
courseid=Entry(tab3,width=50,borderwidth=2)
courseid.grid(row=0,column=4,columnspan=2, padx = 10, pady = 45)

Label(tab3,text ="Course Name",font = ("Times New Roman", 12)).grid(column =1,row = 1,columnspan=2,sticky=E, padx = 10, pady = 5)
coursename=Entry(tab3,width=50,borderwidth=2)
coursename.grid(row=1,column=4,columnspan=2, padx = 10, pady = 45)

def clear9():
        courseid.delete(0,END)
        coursename.delete(0,END)

def msg_submit1():
    #-----------------------Message:Displaying of successful entry-----------------------------------

    messagebox.showinfo("Save", "Course added")
    clear9()
def clearDetails():
        #-----------------------Message:Displaying of successful deletion-----------------------------------

        messagebox.showinfo("Status", "Cleared")
        clear9()

#----------------------Saving Details---------------------------------

def saveDetails():
        e1=courseid.get()
        e2=coursename.get()
        r={"CourseID": e1, "CourseName": e2}
        msg_submit1()
        with open('Course.json') as f:
                data1=json.load(f)
        data1["Courses"].append(r)
        data_serialise=json.dumps(data1, indent=2)

        with open('Course.json','w') as f:
                json.dump(data1,f,indent=1)


#----------------------------SUBMIT-&-CLEAR-BUTTONS----------------------------------------

Button(tab3,text="Submit",command=saveDetails, width = 18).grid(column =4,row = 2,columnspan=1,sticky=W, padx = 10, pady = 45)
Button(tab3,text="Clear",command=clearDetails, width = 18).grid(column =5,row = 2,columnspan=1,sticky=W, padx = 10, pady = 45)




#-----------------------------------------------------------------------------------
#------------------------------Window 4 Display Course -----------------------------
win4_tree=ttk.Treeview(tab4)
#-----------------------------DEFINING COLUMNS----------------------------------------------
win4_tree['columns']=('CourseID','CourseName')
#-----------------------------FORMATTING  COLUMNS---------------------------------------------
win4_tree.column('#0',width=0,minwidth=0)
win4_tree.column('CourseID',width=80,minwidth=80)
win4_tree.column('CourseName',width=120,minwidth=120)
# ------------------------------------HEADING---------------------------------------------
win4_tree.heading('#0',text="",anchor=W)
win4_tree.heading('CourseID',text="CourseID",anchor=W)
win4_tree.heading('CourseName',text="CourseName",anchor=W)

def show1():
        win4_tree.delete(*win4_tree.get_children())
        # insert data
        with open('Course.json') as f:
                data1=json.load(f)
        temp=0
        for i in data1['Courses']:
                win4_tree.insert(parent='',index='end',iid=temp,text='',values=(i["CourseID"],i["CourseName"]))
                temp+=1
        # place
        win4_tree.place(x=0,y=0,width=800)

Button(tab4,text="Display",bg='black',fg='white',command=show1).place(x=350,y=300)



for i in range(6):
    tab5.columnconfigure(i,weight=1)

Label(tab5,text ="Student Roll no",font = ("Times New Roman", 12)).grid(column =1,row = 0,columnspan=2,sticky=E, padx = 10, pady = 45)
rollno1=Entry(tab5,width=50,borderwidth=2)
rollno1.grid(row=0,column=4,columnspan=2, padx = 10, pady = 45)

Label(tab5,text ="Course Name",font = ("Times New Roman", 12)).grid(column =1,row = 1,columnspan=2,sticky=E, padx = 10, pady = 5)
s=StringVar() 
allocate = ttk.Combobox(tab5, state='readonly',width = 48,textvariable=s) 

with open('Course.json') as f:
        data1=json.load(f) 
allo=[]
for i in data1['Courses']:
                allo.append(i['CourseName'])
def refresh():
        with open('Course.json') as f:
                data2=json.load(f)
        global allo
        allo=[]
        for i in data2['Courses']:
                allo.append(i['CourseName'])
        allocate['values']=allo
allocate['values'] = allo
allocate.grid(column = 4, row = 1, padx = 10, pady = 5,columnspan=2) 
 
allocate.current(0)

Button(tab5,text="Refresh",bg='black',fg='white',command=refresh).place(x=350,y=300)
#----------------------------------------------------------------------------------
def clear2():
        rollno1.delete(0,END)

def msg_submit2():
    #-----------------------Message:Displaying of successful entry-----------------------------------
    messagebox.showinfo("Save", "Course added")
    clear2()
def msg_clear2():
        #-----------------------Message:Displaying of successful deletion-----------------------------------
        messagebox.showinfo("Status", "Cleared")
        clear2()
with open('Course.json') as f:
        data5=json.load(f)
def return_courseID(cn):
        for i in data5['Courses']:
                if i['CourseName']==cn:
                        return i['CourseID']
def course_add1():
        f1=rollno1.get()
        f2=s.get()
        f3=return_courseID(f2)
        r={"Rollno": f1, "CourseID": f3}
        msg_submit2()
        with open('Allocation.json') as f:
                data3=json.load(f)
        data3["Stu_Course"].append(r)
        data_serialise=json.dumps(data3, indent=2)
        with open('Allocation.json','w') as f:
                json.dump(data3,f,indent=1)





Button(tab5,text="Allocate",command=course_add1 ,width = 18).grid(column =4,row = 2,columnspan=1,sticky=W, padx = 10, pady = 45)
Button(tab5,text="Clear", command=msg_clear2,width = 18).grid(column =5,row = 2,columnspan=1,sticky=W, padx = 10, pady = 45)


#---------------------------------(TAB-6)--------------------------------------------------

win6_tree=ttk.Treeview(tab6)
# define Our Columns
win6_tree['columns']=('Rollno','CourseID')
# Formate Our Columns
win6_tree.column('#0',width=0,minwidth=0)
win6_tree.column('Rollno',width=80,minwidth=80)
win6_tree.column('CourseID',width=120,minwidth=120)
# Create Headings
win6_tree.heading('#0',text="",anchor=W)
win6_tree.heading('Rollno',text="Rollno",anchor=W)
win6_tree.heading('CourseID',text="CourseID",anchor=W)
#------------ SHOW
def show2():
        win6_tree.delete(*win6_tree.get_children())
        # insert data
        with open('Allocation.json') as f:
                data3=json.load(f)
        temp=0
        for i in data3['Stu_Course']:
                win6_tree.insert(parent='',index='end',iid=temp,text='',values=(i["Rollno"],i["CourseID"]))
                temp+=1
        # place
        win6_tree.place(x=0,y=0,width=800)

Button(tab6,text="Display",bg='black',fg='white',command=show2).place(x=350,y=300)

mainloop()
